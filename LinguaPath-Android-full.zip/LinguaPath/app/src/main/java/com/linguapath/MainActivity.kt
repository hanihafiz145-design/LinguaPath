package com.linguapath

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.max

private val Activity.dataStore by preferencesDataStore("linguapath")

data class Lang(val code:String,val name:String,val locale:String=code)
data class Vocab(val target:String,val native:String,val example:String)
data class Lesson(val id:Int,val title:String,val topic:String,val vocab:List<Vocab>,val phrase:String,val translation:String)

data class ReviewItem(val target:String,val native:String,val misses:Int)

val languages = listOf(
    Lang("ar","العربية","ar-SA"),Lang("en","English","en-US"),Lang("fr","Français","fr-FR"),Lang("es","Español","es-ES"),Lang("de","Deutsch","de-DE"),Lang("it","Italiano","it-IT"),Lang("pt","Português","pt-PT"),Lang("ru","Русский","ru-RU"),Lang("tr","Türkçe","tr-TR"),Lang("zh","中文","zh-CN"),Lang("ja","日本語","ja-JP"),Lang("ko","한국어","ko-KR"),Lang("hi","हिन्दी","hi-IN"),Lang("fa","فارسی","fa-IR"),Lang("nl","Nederlands","nl-NL"),Lang("sv","Svenska","sv-SE"),Lang("no","Norsk","nb-NO"),Lang("da","Dansk","da-DK"),Lang("fi","Suomi","fi-FI"),Lang("pl","Polski","pl-PL"),Lang("uk","Українська","uk-UA"),Lang("el","Ελληνικά","el-GR"),Lang("he","עברית","he-IL"),Lang("cs","Čeština","cs-CZ"),Lang("ro","Română","ro-RO"),Lang("hu","Magyar","hu-HU"),Lang("id","Bahasa Indonesia","id-ID"),Lang("vi","Tiếng Việt","vi-VN")
)

fun turkishLessons() = listOf(
    Lesson(1,"التحيات","الأساسيات",listOf(Vocab("Merhaba","مرحبًا","Merhaba, nasılsın?"),Vocab("Teşekkür ederim","شكرًا لك","Teşekkür ederim, çok iyiyim."),Vocab("Lütfen","من فضلك","Bir kahve, lütfen."),Vocab("Evet","نعم","Evet, hazırım."),Vocab("Hayır","لا","Hayır, teşekkürler."),Vocab("Günaydın","صباح الخير","Günaydın!")),"Merhaba, nasılsın?","مرحبًا، كيف حالك؟"),
    Lesson(2,"التعريف بالنفس","المحادثة اليومية",listOf(Vocab("Benim adım...","اسمي...","Benim adım Ahmet."),Vocab("Nerelisin?","من أين أنت؟","Nerelisin?"),Vocab("Suriyeliyim","أنا سوري","Ben Suriyeliyim."),Vocab("Memnun oldum","تشرفت بمعرفتك","Memnun oldum."),Vocab("Görüşürüz","أراك لاحقًا","Yarın görüşürüz."),Vocab("Ben...im","أنا...","Ben öğrenciyim.")),"Benim adım Ali. Suriyeliyim.","اسمي علي. أنا سوري."),
    Lesson(3,"الأرقام والوقت","الأرقام",listOf(Vocab("bir","واحد","Bir kahve."),Vocab("iki","اثنان","İki kişi."),Vocab("üç","ثلاثة","Üç gün."),Vocab("bugün","اليوم","Bugün pazartesi."),Vocab("yarın","غدًا","Yarın görüşürüz."),Vocab("saat","ساعة/الوقت","Saat üç.")),"Bugün saat üç.","اليوم الساعة الثالثة."),
    Lesson(4,"العائلة","الأشخاص",listOf(Vocab("anne","أم","Annem evde."),Vocab("baba","أب","Babam çalışıyor."),Vocab("kardeş","أخ/أخت","Bir kardeşim var."),Vocab("aile","عائلة","Ailem büyük."),Vocab("arkadaş","صديق","O benim arkadaşım."),Vocab("çocuk","طفل","Çocuk burada.")),"Ailem çok büyük.","عائلتي كبيرة جدًا."),
    Lesson(5,"الطعام","الحياة اليومية",listOf(Vocab("su","ماء","Bir su, lütfen."),Vocab("kahve","قهوة","Bir kahve istiyorum."),Vocab("ekmek","خبز","Ekmek alıyorum."),Vocab("yemek","طعام/وجبة","Yemek hazır."),Vocab("lezzetli","لذيذ","Bu yemek çok lezzetli."),Vocab("istiyorum","أريد","Kahve istiyorum.")),"Bir kahve, lütfen.","قهوة واحدة، من فضلك."),
    Lesson(6,"المطعم","السفر",listOf(Vocab("menü","قائمة الطعام","Menüyü alabilir miyim?"),Vocab("hesap","الحساب","Hesap, lütfen."),Vocab("istiyorum","أريد","Su istiyorum."),Vocab("ne kadar","كم السعر","Bu ne kadar?"),Vocab("başka","آخر/شيء آخر","Başka bir şey?"),Vocab("tabii","طبعًا","Tabii.")),"Bir kahve ve su istiyorum, lütfen.","أريد قهوة وماء، من فضلك."),
    Lesson(7,"التسوق","الحياة اليومية",listOf(Vocab("mağaza","متجر","Mağaza nerede?"),Vocab("fiyat","سعر","Fiyat ne kadar?"),Vocab("ucuz","رخيص","Bu ucuz."),Vocab("pahalı","غالي","Bu çok pahalı."),Vocab("satın almak","شراء","Bunu satın almak istiyorum."),Vocab("bunu","هذا","Bunu istiyorum.")),"Bu ne kadar?","كم سعر هذا؟"),
    Lesson(8,"المواصلات","السفر",listOf(Vocab("otobüs","حافلة","Otobüs nerede?"),Vocab("taksi","تاكسي","Bir taksi çağırabilir misiniz?"),Vocab("istasyon","محطة","İstasyon nerede?"),Vocab("sağ","يمين","Sağa dönün."),Vocab("sol","يسار","Sola dönün."),Vocab("düz","مستقيم","Düz gidin.")),"İstasyon nerede?","أين المحطة؟"),
    Lesson(9,"الفندق","السفر",listOf(Vocab("otel","فندق","Otel nerede?"),Vocab("oda","غرفة","Bir oda istiyorum."),Vocab("rezervasyon","حجز","Rezervasyonum var."),Vocab("pasaport","جواز سفر","Pasaportum burada."),Vocab("anahtar","مفتاح","Oda anahtarı nerede?"),Vocab("gece","ليلة","Bir gece kalacağım.")),"Bir odam var, rezervasyonum var.","لدي غرفة، لدي حجز."),
    Lesson(10,"المحادثة اليومية","المحادثة",listOf(Vocab("nasılsın","كيف حالك","Nasılsın?"),Vocab("iyiyim","أنا بخير","İyiyim, teşekkür ederim."),Vocab("nerede","أين","Tuvalet nerede?"),Vocab("yardım","مساعدة","Yardım eder misiniz?"),Vocab("anlamıyorum","لا أفهم","Türkçe anlamıyorum."),Vocab("tekrar","مرة أخرى","Tekrar eder misiniz?")),"İyiyim, teşekkür ederim. Sen nasılsın?","أنا بخير، شكرًا لك. وأنت كيف حالك؟")
)

class MainVM: ViewModel() {
    var screen by mutableStateOf("native")
    var native by mutableStateOf<Lang?>(null)
    var target by mutableStateOf<Lang?>(null)
    var level by mutableStateOf("مبتدئ")
    var goal by mutableStateOf("المحادثة اليومية")
    var currentLesson by mutableIntStateOf(1)
    var xp by mutableIntStateOf(0)
    var completed by mutableStateOf(setOf<Int>())
    var reviews by mutableStateOf(listOf<ReviewItem>())
    var feedback by mutableStateOf("")
    var loaded by mutableStateOf(false)
    val lessons get() = if(target?.code=="tr") turkishLessons() else turkishLessons()

    fun chooseNative(l:Lang){ native=l; screen="target" }
    fun chooseTarget(l:Lang){ if(l.code!=native?.code){ target=l; screen="level" } }
    fun finishSetup(){ screen="plan" }
    fun start(){ screen="dashboard" }
    fun openLesson(id:Int=currentLesson){ currentLesson=id.coerceIn(1,lessons.size); screen="lesson" }
    fun complete(id:Int){
        if(!completed.contains(id)){ completed=completed+id; xp+=20 }
        currentLesson=max(1,(id+1).coerceAtMost(lessons.size)); screen="dashboard"
    }
    fun addReview(v:Vocab){
        val old=reviews.find{it.target==v.target}
        reviews=if(old==null) reviews+(ReviewItem(v.target,v.native,1)) else reviews.map{if(it.target==v.target)it.copy(misses=it.misses+1) else it}
    }
    fun removeReview(target:String){reviews=reviews.filterNot{it.target==target}}
}

class MainActivity: ComponentActivity() {
    private var tts: TextToSpeech?=null
    override fun onCreate(b:Bundle?){super.onCreate(b);tts=TextToSpeech(this){};setContent{LinguaPathApp(viewModel(),this,tts)}}
    override fun onDestroy(){tts?.shutdown();super.onDestroy()}
}

@Composable fun LinguaPathApp(vm:MainVM,activity:Activity,tts:TextToSpeech?) {
    val scope=rememberCoroutineScope()
    LaunchedEffect(Unit){
        val p=activity.dataStore.data.first()
        vm.native=languages.firstOrNull{it.code==p[stringPreferencesKey("native")]}
        vm.target=languages.firstOrNull{it.code==p[stringPreferencesKey("target")]}
        vm.level=p[stringPreferencesKey("level")] ?: "مبتدئ"
        vm.goal=p[stringPreferencesKey("goal")] ?: "المحادثة اليومية"
        vm.currentLesson=p[intPreferencesKey("lesson")] ?: 1
        vm.xp=p[intPreferencesKey("xp")] ?: 0
        vm.completed=p[stringSetPreferencesKey("completed")]?.mapNotNull{it.toIntOrNull()}?.toSet() ?: emptySet()
        vm.loaded=true
        if(vm.native!=null&&vm.target!=null)vm.screen="dashboard"
    }
    LaunchedEffect(vm.native,vm.target,vm.level,vm.goal,vm.currentLesson,vm.xp,vm.completed){
        if(vm.loaded)activity.dataStore.edit{e->vm.native?.let{e[stringPreferencesKey("native")]=it.code};vm.target?.let{e[stringPreferencesKey("target")]=it.code};e[stringPreferencesKey("level")]=vm.level;e[stringPreferencesKey("goal")]=vm.goal;e[intPreferencesKey("lesson")]=vm.currentLesson;e[intPreferencesKey("xp")]=vm.xp;e[stringSetPreferencesKey("completed")]=vm.completed.map{it.toString()}.toSet()}
    }
    val rtl=vm.native?.code=="ar"||vm.native==null
    MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF7C6CFF),secondary=Color(0xFF36D1DC),background=Color(0xFF070A12),surface=Color(0xFF111827))) {
        Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background){
            CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides if(rtl)LayoutDirection.Rtl else LayoutDirection.Ltr){
                if(!vm.loaded)Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator()}
                else when(vm.screen){
                    "native"->LanguageScreen("🌍 ما لغتك الأصلية؟","اختر لغة واجهة التطبيق",languages){vm.chooseNative(it)}
                    "target"->LanguageScreen("🗣️ ما اللغة التي تريد تعلمها؟","لا يمكنك اختيار لغتك الأصلية",languages.filter{it.code!=vm.native?.code}){vm.chooseTarget(it)}
                    "level"->ChoiceScreen("📊 ما مستواك الحالي؟",listOf("مبتدئ تمامًا","مبتدئ","متوسط","فوق المتوسط","متقدم")){vm.level=it;vm.screen="goal"}
                    "goal"->ChoiceScreen("🎯 لماذا تريد تعلم اللغة؟",listOf("المحادثة اليومية","السفر","الدراسة","العمل","السياحة","القراءة والكتابة","الاستماع","النطق","تعلم اللغة بشكل شامل","هدف مخصص")){vm.goal=it;vm.finishSetup()}
                    "plan"->PlanScreen(vm){vm.start()}
                    "dashboard"->Dashboard(vm,{vm.openLesson()},{vm.screen="review"},{vm.screen="conversation"})
                    "lesson"->LessonScreen(vm,tts,activity)
                    "review"->ReviewScreen(vm,tts)
                    "conversation"->ConversationScreen(vm,tts,activity)
                }
            }
        }
    }
}

@Composable fun Header(title:String,sub:String?=null){Column(Modifier.padding(24.dp)){Text(title,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);if(sub!=null){Spacer(Modifier.height(8.dp));Text(sub,color=Color.LightGray)}}}

@Composable fun LanguageScreen(title:String,sub:String,list:List<Lang>,onPick:(Lang)->Unit){Column{Header(title,sub);LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp)){items(list){l->Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable{onPick(l)},shape=RoundedCornerShape(16.dp)){Text(l.name,Modifier.padding(20.dp),style=MaterialTheme.typography.titleMedium)}}}}}
@Composable fun ChoiceScreen(title:String,choices:List<String>,onPick:(String)->Unit){Column{Header(title);LazyColumn(Modifier.fillMaxSize().padding(16.dp)){items(choices){c->Button({onPick(c)},Modifier.fillMaxWidth().padding(vertical=6.dp).height(52.dp),shape=RoundedCornerShape(16.dp)){Text(c)}}}}}

@Composable fun PlanScreen(vm:MainVM,onStart:()->Unit){Column(Modifier.fillMaxSize()){Header("🎉 تم إنشاء خطتك!","${vm.native?.name} → ${vm.target?.name}\nالمستوى: ${vm.level}\nالهدف: ${vm.goal}");LazyColumn(Modifier.weight(1f).padding(horizontal=20.dp)){items(vm.lessons.chunked(5)){week->Card(Modifier.fillMaxWidth().padding(vertical=6.dp)){Column(Modifier.padding(18.dp)){Text("الأسبوع ${(week.first().id-1)/5+1}",fontWeight=FontWeight.Bold);week.forEach{Text("الدرس ${it.id}: ${it.title}",Modifier.padding(top=8.dp),color=Color.LightGray)}}}}};Button(onStart,Modifier.fillMaxWidth().padding(20.dp).height(54.dp)){Text("ابدأ التعلم")}}}

@Composable fun Dashboard(vm:MainVM,onLessons:()->Unit,onReview:()->Unit,onConversation:()->Unit){Column(Modifier.fillMaxSize()){Header("LinguaPath","${vm.native?.name} → ${vm.target?.name}");Card(Modifier.padding(horizontal=20.dp).fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("مستواك الحالي: A1",fontWeight=FontWeight.Bold);Text("⭐ ${vm.xp} XP");Text("التقدم: ${vm.completed.size} / ${vm.lessons.size}");Spacer(Modifier.height(10.dp));LinearProgressIndicator(progress={vm.completed.size.toFloat()/vm.lessons.size},Modifier.fillMaxWidth())}};Button(onLessons,Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=10.dp).height(54.dp)){Text("📚 متابعة الدروس (${vm.currentLesson})")};Button(onConversation,Modifier.fillMaxWidth().padding(horizontal=20.dp).height(54.dp)){Text("🎙️ المحادثة الصوتية")};OutlinedButton(onReview,Modifier.fillMaxWidth().padding(20.dp).height(52.dp)){Text("🔄 مراجعة الكلمات (${vm.reviews.size})")}}}

@Composable fun LessonScreen(vm:MainVM,tts:TextToSpeech?,activity:Activity){
    val lesson=vm.lessons[vm.currentLesson-1];var quiz by rememberSaveable(lesson.id){mutableIntStateOf(0)};var translation by rememberSaveable(lesson.id){mutableStateOf("")};var heard by rememberSaveable(lesson.id){mutableStateOf("")};var listening by rememberSaveable(lesson.id){mutableStateOf(false)};var sort by rememberSaveable(lesson.id){mutableStateOf("")};var quiz2 by rememberSaveable(lesson.id){mutableIntStateOf(0)}
    val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){granted->if(granted){startRecognizer(activity,vm.target?.locale ?: "tr-TR")}}
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->heard=r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty();listening=false}
    fun listen(){tts?.language=Locale.forLanguageTag(vm.target?.locale ?: "tr-TR");tts?.speak(lesson.phrase,TextToSpeech.QUEUE_FLUSH,null,"phrase")}
    Column(Modifier.fillMaxSize()){Header("الدرس ${lesson.id}: ${lesson.title}",lesson.topic);LazyColumn(Modifier.weight(1f).padding(horizontal=18.dp)){
        item{Text("📚 كلمات جديدة",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
        items(lesson.vocab){v->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(v.target,fontWeight=FontWeight.Bold);Text(v.native,color=Color.LightGray);Text(v.example,color=Color.Gray)}};IconButton(onClick={tts?.language=Locale.forLanguageTag(vm.target?.locale ?: "tr-TR");tts?.speak(v.target,TextToSpeech.QUEUE_FLUSH,null,"word")}){Text("🔊")}};TextButton(onClick={listen}){Text("🔊 اسمع المثال")}}}
        item{Card(Modifier.fillMaxWidth().padding(vertical=10.dp)){Column(Modifier.padding(18.dp)){Text("🎙️ النطق الحقيقي",fontWeight=FontWeight.Bold);Text("قل: ${lesson.phrase}");Text("المطلوب: ${lesson.translation}",color=Color.Gray);if(heard.isNotBlank()){Text("ما سمعه التطبيق: $heard",Modifier.padding(top=8.dp));val exact=normalize(heard)==normalize(lesson.phrase);Text(if(exact)"مطابقة نصية قوية ✅ +5 XP" else "النص المسموع لا يطابق الجملة بالكامل 🟡",Modifier.padding(top=6.dp));if(exact&&quiz2==0){quiz2=3;vm.xp+=5}};Button(onClick={if(activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){val i=recognizerIntent(vm.target?.locale ?: "tr-TR");listening=true;launcher.launch(i)}else permission.launch(Manifest.permission.RECORD_AUDIO)},Modifier.fillMaxWidth().padding(top=10.dp)){Text(if(listening)"جارٍ الاستماع..." else "🎙️ تحدث الآن")};Text("ملاحظة: النتيجة هنا مبنية على الكلام الذي تعرّف عليه الهاتف. لا يتم الادعاء بتحليل صوتي دقيق دون محرك تقييم نطق مخصص.",color=Color.Gray,style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(top=8.dp))}}}
        item{Text("✍️ تمارين",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=8.dp));Text("1) اختيار الإجابة الصحيحة: Merhaba تعني؟");Button({quiz=1;vm.xp+=5},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text("مرحبًا")};OutlinedButton({quiz=2;vm.addReview(lesson.vocab[0])},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text("شكرًا")};if(quiz==1)Text("إجابة صحيحة! +5 XP 🎉",color=MaterialTheme.colorScheme.secondary);if(quiz==2)Text("أضيفت للمراجعة 🔄",color=Color.Yellow)
            Text("2) ترجمة: ${lesson.translation}");OutlinedTextField(translation,{translation=it},Modifier.fillMaxWidth().padding(vertical=6.dp),singleLine=true);Button({if(translation.trim().isNotEmpty()){vm.xp+=5;quiz2=4}},Modifier.fillMaxWidth()){Text("تحقق")};if(quiz2==4)Text("تم تسجيل المحاولة +5 XP",color=MaterialTheme.colorScheme.secondary)
            Text("3) ترتيب الكلمات: ${lesson.phrase.split(" ").reversed().joinToString(" / ")}");OutlinedTextField(sort,{sort=it},Modifier.fillMaxWidth().padding(vertical=6.dp),singleLine=true);Button({if(sort.trim().isNotEmpty()){vm.xp+=5;quiz2=5}},Modifier.fillMaxWidth()){Text("تحقق")};if(quiz2==5)Text("تم تسجيل المحاولة +5 XP",color=MaterialTheme.colorScheme.secondary)
            Text("4) استماع");Button({listen();quiz2=6},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text("🔊 اسمع ثم أجب")};if(quiz2==6)Text("استمع للجملة وحاول تذكر معناها.")
        }
    };Button(onClick={vm.complete(lesson.id)},Modifier.fillMaxWidth().padding(18.dp).height(54.dp)){Text(if(lesson.id==vm.lessons.size)"🎉 إنهاء المسار" else "➡️ الدرس التالي")}}
}

fun normalize(s:String)=s.lowercase(Locale.ROOT).replace("[.,!?]".toRegex(),"").replace("\\s+".toRegex()," ").trim()
fun recognizerIntent(locale:String)=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,locale);putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,5)}
fun startRecognizer(activity:Activity,locale:String){activity.startActivityForResult(recognizerIntent(locale),99)}

@Composable fun ReviewScreen(vm:MainVM,tts:TextToSpeech?){Column(Modifier.fillMaxSize()){Header("🔄 مراجعة","الكلمات التي أخطأت بها تعود هنا");if(vm.reviews.isEmpty())Text("لا توجد كلمات صعبة بعد. أكمل التمارين ليبني التطبيق قائمة المراجعة.",Modifier.padding(24.dp),color=Color.Gray)else LazyColumn(Modifier.fillMaxSize().padding(16.dp)){items(vm.reviews){r->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Row(Modifier.fillMaxWidth().padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(r.target,fontWeight=FontWeight.Bold);Text(r.native,color=Color.LightGray);Text("أخطاء: ${r.misses}",color=Color.Gray)};IconButton(onClick={tts?.language=Locale.forLanguageTag(vm.target?.locale ?: "tr-TR");tts?.speak(r.target,TextToSpeech.QUEUE_FLUSH,null,"review")}){Text("🔊")};TextButton(onClick={vm.removeReview(r.target)}){Text("✓")}}}}}}}

@Composable fun ConversationScreen(vm:MainVM,tts:TextToSpeech?,activity:Activity){
    var heard by rememberSaveable{mutableStateOf("")};var assistant by rememberSaveable{mutableStateOf("Merhaba! Nasılsın?")};var listening by rememberSaveable{mutableStateOf(false)}
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->heard=r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty();listening=false;if(heard.isNotBlank())assistant=conversationReply(heard)}
    val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){if(it)launcher.launch(recognizerIntent(vm.target?.locale ?: "tr-TR"))}
    Column(Modifier.fillMaxSize()){Header("🎙️ محادثة","حوار فعلي باستخدام الميكروفون + التعرف على الكلام");Card(Modifier.fillMaxWidth().padding(20.dp)){Column(Modifier.padding(20.dp)){Text("المدرب",fontWeight=FontWeight.Bold);Text(assistant,Modifier.padding(vertical=12.dp));Text("أنت",fontWeight=FontWeight.Bold);Text(heard.ifBlank{"تحدث للبدء..."},color=Color.LightGray)}};Button(onClick={tts?.let{it.language=Locale.forLanguageTag(vm.target?.locale ?: "tr-TR");it.speak(assistant,TextToSpeech.QUEUE_FLUSH,null,"coach")}},Modifier.fillMaxWidth().padding(horizontal=20.dp)){Text("🔊 اسمع المدرب")};Button(onClick={if(activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)launcher.launch(recognizerIntent(vm.target?.locale ?: "tr-TR"))else permission.launch(Manifest.permission.RECORD_AUDIO)},Modifier.fillMaxWidth().padding(20.dp).height(55.dp)){Text(if(listening)"جارٍ الاستماع..." else "🎙️ تحدث الآن")};Text("هذه المحادثة تعمل محليًا بحوار تدريبي محدد. لإضافة محادثة AI مفتوحة، اربط Backend ومفتاح نموذج، ولن يتم وضع مفتاح سري داخل التطبيق.",Modifier.padding(20.dp),color=Color.Gray);Button({vm.xp+=10},Modifier.fillMaxWidth().padding(20.dp)){Text("إكمال تدريب المحادثة +10 XP")}}
}

fun conversationReply(input:String):String{val s=normalize(input);return when{listOf("merhaba","selam").any{s.contains(it)}->"Merhaba! Nasılsın?";s.contains("iyi")||s.contains("iyiyim")->"Harika! Bugün ne yapıyorsun?";s.contains("kahve")->"Tabii. Başka bir şey ister misiniz?";s.contains("su")->"Tabii. Bir su hemen geliyor.";else->"Anladım. Biraz daha söyleyebilir misin?"}}
